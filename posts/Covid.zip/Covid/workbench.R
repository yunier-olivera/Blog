

# plots -------------------------------------------------------------------


# overall plots

p <- covid_cuba_diagn |> 
  group_by(id) |> 
  summarise(diagnosed = n()) |> 
  mutate(id = as.numeric(id)) |> 
  full_join(covid_cuba_stats) |>
  ungroup() |> 
  arrange(fecha) |> 
  mutate(across(c(diagnosed, graves_no:`60_`), ~replace_na(., 0)), 
         muertes_cum =  cumsum(muertes_no),
         recuperados_cum = cumsum(recuperados_no),
         diagnosticados_cum = cumsum(diagnosed),
         active = diagnosticados_cum - muertes_cum  - recuperados_cum) |>
  select(id, fecha, muertes_no, recuperados_no, diagnosed, 
         active, muertes_cum, recuperados_cum, diagnosticados_cum) |> 
  pivot_longer(cols = -c(id, fecha),
               names_to = "variable") |> 
  ggplot(aes(fecha, value, color = variable)) +
  geom_line()
  
ggplotly(p)



(covid_cuba_stats %>% 
    mutate(muertes_no = replace_na(muertes_no, 0),
           total = cumsum(muertes_no)) %>% 
    ggplot(aes(x = fecha, y = total)) +
    geom_area(fill = "skyblue") +
    theme_pubclean()) %>% 
    ggplotly()


tmp <- covid_cuba_diagn %>%
    group_by(provincia_deteccion) %>% 
    summarise(total = n()) %>% 
    filter(!is.na(provincia_deteccion))# %>% 
    #arrange(total) %>% 
    #mutate(provincia_deteccion = fct_reorder(provincia_deteccion, total))
    
tmp %>% ggplot(aes(x = provincia_deteccion, y = total)) +
    geom_col(fill = "skyblue") +
    geom_text(aes(label = total), cex = 3,
              hjust = ifelse(tmp$total > min(tmp$total) * 3, 1.2, -0.1)) +
    geom_vline(xintercept = c(1.5:15.5), linetype = "dotted", color = "grey") +
    scale_y_discrete(labels = label_number(big.mark = ".")) + #not working
    coord_flip() +
    theme_pubclean() +
    theme(panel.grid.major.y = element_blank())

cuban_adm |> 
    #as_tibble() |> #glimpse()
    #distinct(ADM1_PCODE, ADM1_ES) |> 
    left_join(tmp, by = c("ADM1_ES" = "provincia_deteccion")) |> 
    ggplot(aes(fill = log(total))) +
    #ggplot(aes(fill = log(total))) +
    geom_sf() +
    #scale_fill_continuous(trans = "reverse") +
    scale_fill_distiller(palette = "Spectral") +
    theme_void()

x <- tmp |> 
    mutate(fecha = as.Date("2020-03-10") + as.numeric(id)) |> 
    filter(provincia_deteccion %in% c("Ciego de Ávila", "La Habana",
                                      "Santiago de Cuba", "Matanzas")) |> 
    ggplot(aes(fecha, total, color = provincia_deteccion)) +
    #geom_point() +
    geom_line() +
transition_reveal(along = fecha) +
    labs(title = "Día: {frame_along}")
animate(x)

anim_save("x.mp4", x, width = 8, height = 5, units = "in", res = 300)



fecha <- tmp |> 
    mutate(fecha = as.Date("2020-03-10") + as.numeric(id)) |>
    pull(fecha) |>
    max()

tmp |> 
    mutate(fecha = as.Date("2020-03-10") + as.numeric(id)) |>
    filter(provincia_deteccion %in% c("Villa Clara", "La Habana",
                                      "Santiago de Cuba", "Camagüey",
                                      "Matanzas", "Ciego de Ávila")) |> 
    ggplot(aes(fecha, total, color = provincia_deteccion)) +
    geom_line(show.legend = FALSE) +
    labs(subtitle = paste("Actualizado hasta",  format(fecha, "%b %d, %Y"))) +
    facet_wrap(~provincia_deteccion, scales = "free_y")

tmp |> mutate(fecha = as.Date("2020-03-10") + as.numeric(id)) |> 
    filter(fecha == max(fecha)) |>
    ggplot(aes(fct_reorder(provincia_deteccion, total), total, fill = provincia_deteccion)) +
    geom_bar(stat = "identity", show.legend = FALSE) +
    labs(y = "Nuevos casos Jun 22", x = "") +
    coord_flip() +
    labs(subtitle = paste("Actualizado hasta",  format(fecha, "%b %d, %Y"))) +
    
    
    covid_cuba_death |> 
    mutate(obs = 1) |> 
    group_by(id, provincia_deteccion) |> 
    summarise(fall = sum(obs)) |> 
    filter(provincia_deteccion %in% c("Villa Clara", "La Habana",
                                      "Santiago de Cuba", "Camagüey",
                                      "Matanzas", "Ciego de Ávila")) |> 
    ggplot(aes(as.numeric(id), fall, color = provincia_deteccion)) +
    geom_line() +
    facet_wrap(~provincia_deteccion, scales = "free_y")