
# packages ----------------------------------------------------------------

library(shiny)
library(plotly)             # ggplotly()
library(ggpubr)             # themes for ggplot
library(scales)             # label_number()



# data --------------------------------------------------------------------

source("src/data_processing.R")

overall_plot <- covid_cuba_diagn |> 
  group_by(id) |> 
  summarise(diagnosed = n()) |> 
  mutate(id = as.numeric(id)) |> 
  full_join(covid_cuba_stats) |>
  ungroup() |> 
  arrange(fecha) |> 
  mutate(across(c(diagnosed, graves_no:`60_`), ~replace_na(., 0)), 
         muertes_cum =  cumsum(muertes_no),
         recuperados_cum = cumsum(recuperados_no),
         diagnosticados_cum = cumsum(diagnosed),
         active = diagnosticados_cum - muertes_cum  - recuperados_cum) |>
  select(id, fecha, muertes_no, recuperados_no, diagnosed, 
         active, muertes_cum, recuperados_cum, diagnosticados_cum) |> 
  pivot_longer(cols = -c(id, fecha),
               names_to = "variable") |> 
  mutate(variable =  case_when(
    variable == "muertes_no" ~ "Fallecidos",
    variable == "recuperados_no" ~ "Recuperados",
    variable == "diagnosed" ~ "Nuevos",
    variable == "active" ~ "Activos",
    variable == "muertes_cum" ~ "Total de pacientes fallecidos",
    variable == "recuperados_cum" ~ "Total de pacientes recuperados",
    variable == "diagnosticados_cum" ~ "Total de casos positivos"
  ))



map_diagnosticados <- cuban_adm |>
  left_join(
    left_join(
      covid_cuba_diagn %>%
        group_by(provincia_deteccion) %>% 
        summarise(diagnosticados_prov = n()) %>% 
        filter(!is.na(provincia_deteccion)),
      
      covid_cuba_death %>%
        group_by(provincia_deteccion) %>% 
        summarise(fallecidos_prov = n()) %>% 
        filter(!is.na(provincia_deteccion))
    ) |> 
      pivot_longer(cols = !provincia_deteccion,
                   names_to = "casos"),
    by = c("ADM1_ES" = "provincia_deteccion"))


# app ---------------------------------------------------------------------


ui <- fluidPage(
  
  titlePanel("Covid dashboard de Cuba"),
  
  sidebarLayout(
    sidebarPanel(
      checkboxGroupInput("variable", "Casos:",
                         choices = c("Nuevos", "Recuperados", "Fallecidos",
                                     "Activos", "Total de pacientes fallecidos",
                                     "Total de pacientes recuperados",
                                     "Total de casos positivos"),
                         selected = "Activos"),
      radioButtons("casos", "Mapa:",
                    choices = c("Casos diagnosticados" = "diagnosticados_prov",
                                "Pacientes fallecidos" = "fallecidos_prov"))
    ),
    
    mainPanel(
      plotlyOutput("overall_plot"),
      plotlyOutput("map_diagnosticados")
    )
  )
)

server <- function(input, output) {
  
  output$overall_plot <- renderPlotly({
    
    overall_plot |> filter(variable %in% input$variable) |> 
      ggplot(aes(fecha, value, color = variable)) +
      geom_line() +
      labs(x = "Fecha", y = "Casos")
      theme_pubclean()
    
  })
  
    output$map_diagnosticados <- renderPlotly({
    
     map_diagnosticados |> 
      filter(casos %in% input$casos) |> 
      ggplot(aes(fill = value)) +
      geom_sf() +
      scale_fill_distiller(palette = "Spectral") +
      theme_void()
  })
  
  
  
}

shinyApp(ui = ui, server = server)
