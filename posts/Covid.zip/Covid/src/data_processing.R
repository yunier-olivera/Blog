

###     Covid dashboard for Cuba



# packages ----------------------------------------------------------------

library(jsonlite)           # fromJSON()
library(tidyverse)          # data wrangling
library(janitor)            # clean_names()
library(magrittr)           # extract()
library(lubridate)          # as_date()
library(sf)                 # read_sf()



# functions ---------------------------------------------------------------

source("src/coalesce_join.R")



# data --------------------------------------------------------------------

data_web_site <- "https://covid19cubadata.github.io/data/"

## diagnosticados ---------------------------------------------------------


#covid_cuba1 <- fromJSON(paste0(data_web_site, "covid19-cuba.json"))
#save(list = "covid_cuba1", file = "data/covid19_cuba_20200311_20210704.RData")
load("data/covid19_cuba_20200311_20210704.RData")

covid_cuba2 <- fromJSON(paste0(data_web_site, "covid19-cuba-1.json"))

covid_cuba <- append(covid_cuba1$casos$dias, covid_cuba2$casos$dias)

#   a tibble with every particular case
covid_cuba_diagn <- bind_rows(map(covid_cuba, "diagnosticados"),
                              .id = "id") %>% 
  clean_names() %>% 
  select(id, pais, edad, sexo, municipio_deteccion, provincia_deteccion)


#   get a summary data to fill missing data in covid_cuba_stats below
#   age
tmp_age <- covid_cuba_diagn %>% 
  mutate(edad2 = case_when(
    edad <= 19 ~ "_19",
    edad >= 20 & edad <= 39 ~ "20_39",
    edad >= 40 & edad <= 59 ~ "40_59",
    edad >= 60 ~ "60_"
  )) %>% 
  group_by(id, edad2) %>% 
  summarise(edad_no = n()) %>% 
  pivot_wider(id_cols = id,
              names_from = edad2,
              values_from = edad_no) %>%
  select(-`NA`) %>%
  mutate(id = as.numeric(id))

#   sex
tmp_sex <- covid_cuba_diagn %>% 
  mutate(sexo = case_when(
    sexo == "hombre" ~ "hombres",
    sexo == "mujer" ~ "mujeres"
  )) %>% 
  group_by(id, sexo) %>% 
  summarise(sexo_no = n()) %>% 
  pivot_wider(id_cols = id,
              names_from = sexo,
              values_from = sexo_no) %>%
  select(-`NA`) %>%
  mutate(id = as.numeric(id))


#   names to extract for covid_cuba_stats below
#map(covid_cuba, names) %>%
#    unlist() %>%
#    unique()


#   stats
covid_cuba_stats <- covid_cuba %>% 
  map_depth(., 1, extract, c("fecha", "graves_numero", "criticos_numero",
                             "muertes_numero", "recuperados_numero",
                             "mujeres", "hombres", "_19", "20_39",
                             "40_59", "60_")) %>%
  unlist() %>%
  enframe() %>%
  mutate(name = str_remove(name, ".*\\.")) %>% 
  group_by(name) %>% 
  mutate(id = 1:n(),
         id = ifelse(name == "fecha", id, NA)) %>% 
  ungroup() %>% 
  fill(id, .direction = "down") %>% 
  pivot_wider(id_cols = id,
              names_from = name,
              values_from = value) %>% 
  mutate(across(c(where(is.character), -fecha), as.numeric),
         fecha = as_date(fecha)) %>% 
  rename_with(~str_remove(., "umer"))


#   add some missing data
covid_cuba_stats <- covid_cuba_stats %>%
  coalesce_join(., tmp_age, by = "id") %>% 
  coalesce_join(., tmp_sex, by = "id")




## fallecidos -------------------------------------------------------------

covid_cuba_death_json <- fromJSON(paste0(data_web_site, "covid19-fallecidos.json"))

covid_cuba_death <- bind_rows(map(covid_cuba_death_json[["casos"]][["dias"]],
                                  "fallecidos"),
                              .id = "id") %>% 
  clean_names() |> 
  select(id, pais, edad, sexo, municipio_deteccion,
         provincia_deteccion, enfermedades)



## map --------------------------------------------------------------------

shapefiles <- c("cub_admbnda_adm0_2019.shp",  # cuba clean
                "cub_admbnda_adm1_2019.shp",  # cuba provinces
                "cub_admbnda_adm2_2019.shp",  # cuba municipality
                "cub_admbndl_ALL_2019.shp")   # cuba provinces & municipality

directory <- paste0("C:/Users/yoliv/OneDrive - Instituto Politecnico Nacional/",
                    "Projects/Databases/GIS/Cuba/Cuba_region_prov_municip_2019/")

cuban_adm <- read_sf(paste0(directory, shapefiles[2]))

